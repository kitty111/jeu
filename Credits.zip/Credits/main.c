#include <stdio.h>
#include <stdlib.h>
#include "Credits.h"
#include "/usr/include/SDL/SDL.h"
#include "/usr/include/SDL/SDL_image.h"
#include "/usr/include/SDL/SDL_mixer.h"

int main()
{
	while (1)
	{
		credit();
	}
}	