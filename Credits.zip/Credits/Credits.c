#include <stdio.h>
#include <stdlib.h>
#include "Credits.h"
#include "/usr/include/SDL/SDL.h"
#include "/usr/include/SDL/SDL_image.h"
#include "/usr/include/SDL/SDL_mixer.h"


void credit()
{
SDL_Surface *ecran = NULL, *fond = NULL;
    SDL_Rect positionFond;
    int continuer=1;
        SDL_Event event;
    positionFond.x = 0;
    positionFond.y = 0;
    ecran = SDL_SetVideoMode(900, 1140, 32, SDL_HWSURFACE | SDL_DOUBLEBUF);
    SDL_WM_SetCaption("Credits", NULL);
        fond = IMG_Load("Credits2.png");
        SDL_BlitSurface(fond,NULL,ecran,&positionFond);
        SDL_Flip(ecran);


    while (continuer) //tant qu elle ne vaut pas 0
{
    while(SDL_PollEvent(&event))//lors de l appui sur la touche 
 
{
        if(event.type ==SDL_QUIT)   
       {
continuer=0;
break;
}
}
}

 }
