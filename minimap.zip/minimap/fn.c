/**
* @file fn.c
*/
#include <stdio.h>
#include <stdbool.h>

#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include "/usr/include/SDL/SDL.h"
#include "/usr/include/SDL/SDL_image.h"
#include "/usr/include/SDL/SDL_mixer.h"
#include "/usr/include/SDL/SDL_ttf.h"
#include "type.h"
/*bool collision(SDL_Rect* rect1,SDL_Rect* rect2)
{
    if(rect1->y >= rect2->y + rect2->h)
        return 0;
    if(rect1->x >= rect2->x + rect2->w)
        return 0;
    if(rect1->y + rect1->h <= rect2->y)
        return 0;
    if(rect1->x + rect1->w <= rect2->x)
        return 0;
    return 1;
}*/
/**
* @brief To initialize the character to the right direction .
* @param anim the animation
* @return Nothing
*/
void walk_anim(SDL_Surface *anim[])
{



anim[0]=IMG_Load("pics/1.png");
anim[1]=IMG_Load("pics/2.png");
anim[2]=IMG_Load("pics/3.png");
anim[3]=IMG_Load("pics/4.png");
anim[4]=IMG_Load("pics/5.png");
anim[5]=IMG_Load("pics/6.png");
anim[6]=IMG_Load("pics/7.png");




}

/**
* @brief To initialize the character to the left direction .
* @param back the left direction
* @return Nothing
*/

void walk_back(SDL_Surface *anim[])
{

anim[0]=IMG_Load("pics/17.png");
anim[1]=IMG_Load("pics/16.png");
anim[2]=IMG_Load("pics/15.png");
anim[3]=IMG_Load("pics/14.png");
anim[4]=IMG_Load("pics/13.png");
anim[5]=IMG_Load("pics/12.png");
anim[6]=IMG_Load("pics/11.png");


}


/**
* @brief To display the character  .
* @return Nothing
*/


void display(SDL_Surface *ecran,SDL_Surface *bg,SDL_Surface *img,SDL_Surface *img1,SDL_Surface *img2,SDL_Rect pos,SDL_Rect pos1,SDL_Rect pos2)
{

SDL_BlitSurface(bg,NULL,ecran,NULL);
SDL_BlitSurface(img,NULL,ecran,&pos);
SDL_BlitSurface(img1,NULL,ecran,&pos1);
SDL_BlitSurface(img2,NULL,ecran,&pos2);
SDL_Flip(ecran);
SDL_Delay(1000/30);
}
/**
* @brief To test the minimap .
* @return Nothing
*/

void minimap()
{


SDL_Surface *ecran=NULL,*bg=NULL,*mini_map=NULL,*dot=NULL;
SDL_Rect posmap,posdot;
unit uh;
uh.pos.x=350;
uh.pos.w=95;
uh.pos.h=96;
uh.pos.y=150;
bool b[4]={0,0,0,0};
posmap.x=200;
posmap.y=20;
SDL_Event event;
mini_map=IMG_Load("minimap.png");
int life=300;

int i=0,j=6,done=0,k=0;
bg=SDL_LoadBMP("background2.bmp");
walk_anim(uh.t);
ecran = SDL_SetVideoMode(800,297, 32, SDL_HWSURFACE);
//(ecran,bg,uh.t[k],mini_map,uh.pos,posmap);
dot=IMG_Load("dot.png");
posdot.x=uh.pos.x*1.1;
posdot.y=-10;

while(!done)
{
	//printf(" %d \n",b[3]);
display(ecran,bg,uh.t[k],mini_map,dot,uh.pos,posmap,posdot);

while(SDL_PollEvent(&event))
{
    if(event.type==SDL_QUIT)
    {
        done=1;
        break;

    }
 switch(event.type)
         {
          /**/

           case SDL_QUIT:
           done=1;
           break;
           case SDL_KEYDOWN:
           {
             switch(event.key.keysym.sym)
             {
                case SDLK_UP:
                  b[0]=1;
                break;
                case SDLK_LEFT:
                  b[1]=1;
                break;
                case SDLK_DOWN:
                  b[2]=1;
                break;
                case SDLK_RIGHT:
                  b[3]=1;
                break;
                


             }
              

             break;



           }



           case SDL_KEYUP:
           {
             switch(event.key.keysym.sym)
             {
                case SDLK_UP:
                b[0]=0;
                break;
                case SDLK_LEFT:
                b[1]=0;
                break;
                case SDLK_DOWN:
                b[2]=0;
                case SDLK_RIGHT:
                b[3]=0;
                break;






             }
             break;



           }
           

            

         }


    }


printf(" %d ==> %d \n",uh.pos.x,posdot.x);
if(b[1])
{
walk_back(uh.t);
j--;
k=j;
uh.pos.x-=5;
if(posdot.x>358)
posdot.x-=1;
if(j==0)
{

  j=6;
}
}
if(b[3])
{
walk_anim(uh.t);
i++;
uh.pos.x+=5;

if(posdot.x<571)
printf("aa");

posdot.x+=1;

k=i;
if(i>=6)
{

  i=0;
}
}

}



}




