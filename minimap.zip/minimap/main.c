#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include "/usr/include/SDL/SDL.h"
#include "/usr/include/SDL/SDL_image.h"
#include "/usr/include/SDL/SDL_mixer.h"
#include "/usr/include/SDL/SDL_ttf.h"
#include "type.h"
/**
* @file main.c
* @brief Testing Program.
* @author Spicy
* @version 0.1
* @date Apr 01, 2015
*
* Testing program for mini map
*
*/
int main()
{

minimap();
	
}
