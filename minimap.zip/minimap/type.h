#ifndef TYPE_H_INCLUDE
#define TYPE_H_INCLUDE
/**
* @struct unit
* @brief struct for units
*/
typedef struct 
{
	SDL_Surface *t[7];
	SDL_Rect pos;
}unit; 
bool collision(SDL_Rect* rect1,SDL_Rect* rect2);
void display(SDL_Surface *ecran,SDL_Surface *bg,SDL_Surface *img,SDL_Surface *img1,SDL_Surface *img2,SDL_Rect pos,SDL_Rect pos1,SDL_Rect pos2);
void minmap();
void walk_back(SDL_Surface *anim[]);
void walk_anim(SDL_Surface *anim[]);

#endif
