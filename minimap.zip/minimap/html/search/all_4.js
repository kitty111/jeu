var searchData=
[
  ['walk_5fanim',['walk_anim',['../fn_8c.html#a601504005ca67c80d157cb5703a480d4',1,'fn.c']]],
  ['walk_5fback',['walk_back',['../fn_8c.html#ade6685ea41a4a443a7594b7db77f1fc1',1,'fn.c']]]
];
