#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include "/usr/include/SDL/SDL.h"
#include "/usr/include/SDL/SDL_image.h"
#include "/usr/include/SDL/SDL_mixer.h"
#include "/usr/include/SDL/SDL_ttf.h"
#include "type.h"

int main()
{

AItest();
	
}