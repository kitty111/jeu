#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include "/usr/include/SDL/SDL.h"
#include "/usr/include/SDL/SDL_image.h"
#include "/usr/include/SDL/SDL_mixer.h"
#include "/usr/include/SDL/SDL_ttf.h"
#include "menu.h"


bool collision(SDL_Rect* rect1,SDL_Rect* rect2)
{
    if(rect1->y >= rect2->y + rect2->h)
        return 0;
    if(rect1->x >= rect2->x + rect2->w)
        return 0;
    if(rect1->y + rect1->h <= rect2->y)
        return 0;
    if(rect1->x + rect1->w <= rect2->x)
        return 0;
    return 1;
}

void init_objet(SDL_Surface*objet[])
{


objet[0]=IMG_Load("fire/fireball_0_01.png");
objet[1]=IMG_Load("fire/fireball_0_02.png");
objet[2]=IMG_Load("fire/fireball_0_03.png");
objet[3]=IMG_Load("fire/fireball_0_04.png");
objet[4]=IMG_Load("fire/fireball_0_05.png");
objet[5]=IMG_Load("fire/fireball_0_06.png");
objet[6]=IMG_Load("fire/fireball_0_07.png");
objet[7]=IMG_Load("fire/fireball_0_08.png");


}

void health_bar(SDL_Surface *health[])
{

    health[0]=IMG_Load("health_bar/health_0.png");
    health[1]=IMG_Load("health_bar/health_1.png");
    health[2]=IMG_Load("health_bar/health_2.png");
    health[3]=IMG_Load("health_bar/health_3.png");
}

void init_objet_1(SDL_Surface*objet [])
{


objet[0]=IMG_Load("fire/fireball_0_11.png");
objet[1]=IMG_Load("fire/fireball_0_12.png");
objet[2]=IMG_Load("fire/fireball_0_13.png");
objet[3]=IMG_Load("fire/fireball_0_14.png");
objet[4]=IMG_Load("fire/fireball_0_15.png");
objet[5]=IMG_Load("fire/fireball_0_16.png");
objet[6]=IMG_Load("fire/fireball_0_17.png");
objet[7]=IMG_Load("fire/fireball_0_18.png");


}


SDL_Color GetPixel(SDL_Surface *surface,int x,int y)
{
  SDL_Color color ;
  Uint32 col = 0 ;

  //determine position
  char* pPosition = ( char* ) surface->pixels ;

  //offset by y
  pPosition += ( surface->pitch * y ) ;

  //offset by x
  pPosition += ( surface->format->BytesPerPixel * x ) ;

  //copy pixel data
  memcpy ( &col , pPosition , surface->format->BytesPerPixel ) ;

  //convert color
  SDL_GetRGB ( col , surface->format , &color.r , &color.g , &color.b ) ;
  return ( color ) ;
}

int Enigme2 ()
    {
    SDL_Surface *ecran = NULL, *fond = NULL,*fond1=NULL;
        SDL_Rect positionFond ;
        SDL_Event event;
        int answer,continuer=1,nb=0;
        positionFond.x = 0;
        positionFond.y = 0;
     //printf("aaa");
        
        //SDL_Init(SDL_INIT_VIDEO);

        ecran = SDL_SetVideoMode(800,594, 32, SDL_HWSURFACE);
        //SDL_WM_SetCaption("Enigme 1", NULL);

        fond= SDL_LoadBMP("Enigme1.bmp");
        SDL_BlitSurface(fond,NULL,ecran,&positionFond);
        SDL_Flip(ecran);
        
        while (continuer) //tant qu elle ne vaut pas 0
    {
      SDL_BlitSurface(fond,NULL,ecran,&positionFond);
        SDL_Flip(ecran);
        while(SDL_PollEvent(&event))//lors de l appui sur la touche 
     
    {
    if(event.type ==SDL_QUIT)   
    {
    continuer=0;
    break;
    }

    switch(event.type)
    {
    case SDL_QUIT:
    continuer=0;
    break;
    case SDL_KEYDOWN:
    {  
     switch(event.key.keysym.sym)
        {
            case SDLK_UP: /* si appui sur flech haut */
                fond1= IMG_Load("Good.png");
                SDL_BlitSurface(fond1,NULL,ecran,&positionFond);
    SDL_Flip(ecran);

    SDL_Delay(2000);
    SDL_BlitSurface(fond,NULL,ecran,&positionFond);
        SDL_Flip(ecran);
     continuer = 0;
               
                break;

            case SDLK_DOWN: /* Si appui sur fleche bas */
                fond1= IMG_Load("False.png");
                SDL_BlitSurface(fond1,NULL,ecran,&positionFond);
    SDL_Flip(ecran);
    SDL_Delay(2000);
        SDL_BlitSurface(fond,NULL,ecran,&positionFond);
        SDL_Flip(ecran);
        
                continuer = 1;
                nb++;
                break;

            case SDLK_RIGHT: /* Si appui sur fleche droit */
                    SDL_BlitSurface(fond1,NULL,ecran,&positionFond);
                SDL_Flip(ecran);
              SDL_Delay(2000);
              SDL_BlitSurface(fond,NULL,ecran,&positionFond);
                SDL_Flip(ecran);
        
                continuer = 1;
                nb++;
                break;
        }
    }
    }
    }
    }

        
        return (continuer);
    }



int collision_Parfaite(SDL_Surface *calque,SDL_Surface *perso,SDL_Rect posperso,int d)
{

  SDL_Color col[3];
  int coll=0, i = 0;
  switch(d){
    case 0: 
    printf("left \n");
      col[0] = GetPixel(calque,posperso.x ,posperso.y);
      col[1] = GetPixel(calque,posperso.x ,posperso.y+ (perso->h/2));
      col[2] = GetPixel(calque,posperso.x ,posperso.y+ perso->h);
      break;
    case 1:
    printf("right \n");
      col[0] = GetPixel(calque,posperso.x+perso->w ,posperso.y);
      col[1] = GetPixel(calque,posperso.x+perso->w ,posperso.y+(perso->h/2));
      col[2] = GetPixel(calque,posperso.x+perso->w ,posperso.y+(perso->h));
      break;
    case 2:
    printf("bottom \n");
      col[0] = GetPixel(calque,posperso.x,posperso.y+(perso->h/2));
      col[1] = GetPixel(calque,posperso.x+(perso->w/2) ,posperso.y+(perso->h/2));
      col[2] = GetPixel(calque,posperso.x+perso->w ,posperso.y+perso->h);
      break;
    case 3:
    printf("top \n");
      col[0] = GetPixel(calque,posperso.x,posperso.y);
      col[1] = GetPixel(calque,posperso.x+(perso->w/2) ,posperso.y);
      col[2] = GetPixel(calque,posperso.x+perso->w ,posperso.y);
      break;
  }
  while(i < 3 && !coll){
    if(col[i].r == 1 && col[i].b == 2 && col[i].g == 2){
      
        coll = 1;
    }
    i++;
   printf("%d %d %d \n", col[i].r ,col[i].b ,col[i].g);

  }
  if(coll){
    printf("collision \n");
  }else{
    printf("non collision \n");
  }
  return coll;
  
}

void walk_anim(SDL_Surface *anim[])
{



anim[0]=IMG_Load("pics/1.png");
anim[1]=IMG_Load("pics/2.png");
anim[2]=IMG_Load("pics/3.png");
anim[3]=IMG_Load("pics/4.png");
anim[4]=IMG_Load("pics/5.png");
anim[5]=IMG_Load("pics/6.png");
anim[6]=IMG_Load("pics/7.png");




}


void walk_back(SDL_Surface *anim[])
{

anim[0]=IMG_Load("pics/17.png");
anim[1]=IMG_Load("pics/16.png");
anim[2]=IMG_Load("pics/15.png");
anim[3]=IMG_Load("pics/14.png");
anim[4]=IMG_Load("pics/13.png");
anim[5]=IMG_Load("pics/12.png");
anim[6]=IMG_Load("pics/11.png");


}


void jump_anim(SDL_Surface *slide_back[])
{


slide_back[0]=IMG_Load("pics/jump_01.png");
slide_back[1]=IMG_Load("pics/jump_02.png");   
slide_back[2]=IMG_Load("pics/jump_03.png");
slide_back[3]=IMG_Load("pics/jump_04.png");
slide_back[4]=IMG_Load("pics/idle.png");
} 
void afficher(SDL_Surface * img1,SDL_Surface * img2,SDL_Surface * img3,SDL_Surface * img4,SDL_Surface * bg,SDL_Surface * ecran,SDL_Rect pos1,SDL_Rect pos2,SDL_Rect pos3,SDL_Rect pos4,SDL_Rect camera,SDL_Rect pospartage,SDL_Rect poss1,SDL_Rect poss2,SDL_Rect poss3,SDL_Rect poss4)
{
SDL_BlitSurface(bg, &camera, ecran, NULL);
SDL_BlitSurface(bg, &camera, ecran, &pospartage);

SDL_BlitSurface(img1, NULL, ecran, &pos1);
SDL_BlitSurface(img2, NULL, ecran, &pos2);
SDL_BlitSurface(img3, NULL, ecran, &pos3);
SDL_BlitSurface(img4, NULL, ecran, &pos4);
SDL_BlitSurface(img1, NULL, ecran, &poss1);
SDL_BlitSurface(img2, NULL, ecran, &poss2);
SDL_BlitSurface(img3, NULL, ecran, &poss3);
SDL_BlitSurface(img4, NULL, ecran, &poss4);
/*SDL_Flip(ecran);
SDL_Delay(1000/30);*/

}
void display(SDL_Surface *ecran,SDL_Surface *bg,SDL_Surface *img,SDL_Surface *img1,SDL_Surface *img2,SDL_Rect pos,SDL_Rect pos1,SDL_Rect pos2)

{

//SDL_BlitSurface(bg,NULL,ecran,NULL);
SDL_BlitSurface(img,NULL,ecran,&pos);
SDL_BlitSurface(img1,NULL,ecran,&pos1);
SDL_BlitSurface(img2,NULL,ecran,&pos2);

/*SDL_Flip(ecran);
SDL_Delay(1000/30);*/
}

void stage()
{
int x,y;

SDL_Surface *ecran = NULL, *imageDeFond = NULL,*enigme=NULL;
    SDL_Rect positionFond,pos,camera,rect_objet,poshealth,game_over,posenigme,pospartage,pos1,rect_objet2,posenigme2,poshealth2,posmap,posdot,posdot2;
    SDL_Surface*idle;
    SDL_Surface *walk[7], *duck, *jump[4],*objet[8],*health[4],*minimap,*dot,*dot2;
    rect_objet.x=1200;
    rect_objet.h=64;
    rect_objet.w=64;
    rect_objet.y=150;
    poshealth.x=-150;
    poshealth.y=-30;
    positionFond.x = 0;
    positionFond.y =0;
    pos.x=320;
    pos.h=91;
    pos.w=33;
    posenigme.x=650;
    posenigme.y=150;
    posenigme.w=45;
    posenigme.h=60;
    pospartage.x=0;
    pospartage.y=300;
    pos1.x=320;
    pos1.y=450;
    rect_objet2.x=1200;
    rect_objet2.h=64;
    rect_objet2.w=64;
    rect_objet2.y=450;
    posenigme2.x=650;
    posenigme2.y=450;
    posenigme2.w=45;
    posenigme2.h=60;
    poshealth2.x=-150;
    poshealth2.y=240;
   posdot2.x=480;
   posdot2.y=-30; 
   posdot.x=450;
   posdot.y=-30; 
   posmap.x=250;
   posmap.y=0;
    bool b[4]={0,0,0,0};
    pos.y=150;
    //pos.h=91;
    //pos.w=33;
SDL_Surface *calque=NULL;
   int i=0,j=1,k=0,s=0,r=0,d=0,indice_objet=0,indice_objet_reverse=7,indice_health=3;
   float t=1000/20;
   int done=0;
   calque = SDL_LoadBMP("mimi2.bmp");
    SDL_Init(SDL_INIT_VIDEO);
camera.h=297;
camera.w=800;
camera.x=0;
camera.y=0;
    ecran = SDL_SetVideoMode(800,594, 32, SDL_HWSURFACE);
    SDL_WM_SetCaption("SKRRRRRRRRRRRRRRRRRRRRRRT", NULL);
enigme=IMG_Load("enigme.png");
       imageDeFond = SDL_LoadBMP("background2.bmp");
 idle=IMG_Load("pics/1.png");
   duck=IMG_Load("pics/sliding_01.png");
/*SDL_BlitSurface(imageDeFond, &camera, ecran, &positionFond);
SDL_BlitSurface(idle, NULL, ecran, &pos);
SDL_Flip(ecran);*/
dot=IMG_Load("dot.png");
dot2=IMG_Load("dot2.png");
minimap=IMG_Load("minimap.png");
 walk_anim(walk);
    init_objet(objet);
    health_bar(health);
  
//camera.y=0;
   while(!done)
   {
   rect_objet.x-=10;
printf("%d ==>%d\n",posdot.x,posdot2.x);
 afficher(walk[i],objet[indice_objet],health[indice_health],enigme,imageDeFond,ecran,pos,rect_objet,poshealth,posenigme,camera,pospartage,pos1,rect_objet2,poshealth2,posenigme2);
   display(ecran,imageDeFond,minimap,dot,dot2,posmap,posdot,posdot2);
   SDL_Flip(ecran);
   SDL_Delay(1000/30);
   indice_objet++;
 if(indice_objet>=7)
 {
  indice_objet=0;

 }

 if(collision(&pos,&rect_objet))
 {
//init_objet_1(objet);
//rect_objet.x+=10;
indice_health--;
game_over.x=-100;
game_over.y=-80;
posenigme.x=380;
posenigme2.x=380;
SDL_Surface *over=IMG_Load("game_over.png");
SDL_BlitSurface(over,NULL,ecran,&game_over);
SDL_Flip(ecran);
SDL_Delay(400);
done=1;
}
if(indice_health==0)
{
done=1;

}
if(posdot.x<=403)
{

  posdot.x=403;
}
if(posdot.x>=624)
{

  posdot.x=624;
}
if(posdot2.x>=624)
{

  posdot2.x=624;
}
if(posdot2.x<=403)
{

  posdot2.x=403;
}


    SDL_Event event;
    while(SDL_PollEvent(&event))
    {
      

//posenigme.x=380;
 if(collision(&pos,&posenigme)/*pos.x==350*/)
 {

//init_objet_1(objet);
//rect_objet.x+=10;
int c=Enigme2();

if(!c)
{
  pos.x+=80;
  break;



}



}
    if(event.type==SDL_QUIT)
    {
        done=1;

    }

         switch(event.type)
         {
          /**/

           case SDL_QUIT:
           done=1;
           break;
           case SDL_KEYDOWN:
           {
             switch(event.key.keysym.sym)
             {
                case SDLK_UP:
                  b[0]=1;
                break;
                case SDLK_LEFT:
                  b[1]=1;
                break;
                case SDLK_DOWN:
                  b[2]=1;
                break;
                case SDLK_RIGHT:
                  b[3]=1;
                break;
                


             }
              

             break;



           }



           case SDL_KEYUP:
           {
             switch(event.key.keysym.sym)
             {
                case SDLK_UP:
                b[0]=0;
                break;
                case SDLK_LEFT:
                b[1]=0;
                break;
                case SDLK_DOWN:
                b[2]=0;
                case SDLK_RIGHT:
                b[3]=0;
                break;






             }
             break;



           }
           

            

         }


    }

if(b[3])  {
  if (!collision_Parfaite(calque,idle,pos,1)){

walk_anim(walk);
//afficher(walk[i],objet[indice_objet],imageDeFond,ecran,pos,rect_objet,camera);
posdot.x+=1;
posdot2.x+=1;

camera.x+=10;
posenigme.x-=10;
posenigme2.x-=10;
rect_objet.x-=20; 

rect_objet2.x-=20; 
i++;
if(i==5)
{

i=0;

}

}else{ b[3]=0;}

}


while(b[0]){
   if (!collision_Parfaite(calque,idle,pos,3))
 {


jump_anim(walk);
afficher(walk[k],objet[indice_objet],health[indice_health],enigme,imageDeFond,ecran,pos,rect_objet,poshealth,posenigme,camera,pospartage,pos1,rect_objet2,poshealth2,posenigme2);
   display(ecran,imageDeFond,minimap,dot,dot2,posmap,posdot,posdot2);
   SDL_Flip(ecran);
   SDL_Delay(1000/30);

 camera.x+=10;
 posenigme.x-=10;
 posenigme2.x-=10;
rect_objet.x-=20;
rect_objet2.x-=20;

pos.y-=40;
pos1.y-=40;

   //printf("%d\n", camera.x);
   if(camera.x>=1240 && b[0])
{

camera.x=1240;
if(pos.x<770||pos1.x<770 )
{
pos.x+=10;
pos1.x+=10;
}
//printf("%d",pos.x);

}

k++;
if(k==3)
{
  while(pos.y!=150)
  {
afficher(walk[k],objet[indice_objet],health[indice_health],enigme,imageDeFond,ecran,pos,rect_objet,poshealth,posenigme,camera,pospartage,pos1,rect_objet2,poshealth2,posenigme2);
   display(ecran,imageDeFond,minimap,dot,dot2,posmap,posdot,posdot2);
   SDL_Flip(ecran);
   SDL_Delay(1000/30);
 
rect_objet.x-=20;
posenigme.x-=10;
rect_objet2.x-=20;
posenigme2.x-=10;

camera.x+=10;
posdot.x+=1;
posdot2.x+=1;

pos.y+=10;
pos1.y+=10;
if(camera.x>=1240 && b[0])
{

camera.x=1240;
if(pos.x<770 || pos1.x<770)
{
pos.x+=10;
pos1.x+=10;
}
//printf("%d",pos.x);

}
}
//afficher(idle,objet[indice_objet],imageDeFond,ecran,pos,rect_objet,camera);


k=0;
b[0]=0; ;
}


}
else
{b[0]=0;}
}



if(b[2])
  {

pos.y=150;
pos1.y+=10;

int z=collision_Parfaite(calque,idle,pos,2);
//camera.x=pos.x;
afficher(duck,objet[indice_objet],health[indice_health],enigme,imageDeFond,ecran,pos,rect_objet,poshealth,posenigme,camera,pospartage,pos1,rect_objet2,poshealth2,posenigme2);
 
   display(ecran,imageDeFond,minimap,dot,dot2,posmap,posdot,posdot2);
   SDL_Flip(ecran);
   SDL_Delay(1000/30);

pos.y=140;
pos1.y=140;

  }



if(b[1]){
  walk_back(walk);
  if (!collision_Parfaite(calque,idle,pos,0))
  {
  //walk_back(walk);
//afficher(walk[j],objet[indice_objet],imageDeFond,ecran,pos,rect_objet,camera);
rect_objet.x-=20;
posenigme.x+=10;
rect_objet2.x-=20;
posenigme2.x+=10;
posdot.x-=1;
posdot2.x-=1;

//pos.x-=10;
   camera.x-=10;
j--;
i=j;
if(j==0)
{

j=6;

}



}
else { b[1]=0;}


}
if(camera.x<=0 && b[1])
{

camera.x=0;
if(pos.x!=0)
pos.x-=10;
pos1.x-=10;

}
if(camera.x>=1240 && b[3])
{

camera.x=1240;
if(pos.x<770)
pos.x+=10;
pos1.x+=10;


}
else if(pos.x>=770)
{
game_over.x=-100;
game_over.y=-80;
SDL_Surface *over=IMG_Load("0.png");
SDL_BlitSurface(over,NULL,ecran,NULL);
SDL_Flip(ecran);
SDL_Delay(1000);
done=1;

}
   } 
   



    SDL_FreeSurface(imageDeFond);   

    SDL_Quit();


}


/*case SDL_MOUSEBUTTONUP:
                {
                SDL_GetMouseState(&x,&y);
                

                   while(pos.x < x)
      {
        walk_anim(walk);
afficher(walk[i],objet[indice_objet],imageDeFond,ecran,pos,rect_objet,camera);
    if (x - pos.x > 10)
    {
pos.x+=10;
camera.x=pos.x;
}
else 
{
  pos.x+=x-pos.x;
  camera.x=pos.x;
afficher(idle,objet[indice_objet],imageDeFond,ecran,pos,rect_objet,camera);

}
   
i++;
if(i==5)
{

i=0;

}
}


      
      
      while(pos.x > x)
      {
/*walk_back(walk);
/afficher(walk[j],objet[indice_objet],imageDeFond,ecran,pos,rect_objet,camera);

camera.x=pos.x;
    SDL_Flip(ecran);
    SDL_Delay(t);*/
/*if (x - pos.x < 10)
    {
pos.x-=10;
}
else 
{
  pos.x-=x-pos.x;
  camera.x=pos.x;
afficher(idle,objet[indice_objet],imageDeFond,ecran,pos,rect_objet,camera);

}
   
j--;
if(j==0)
{
  camera.x=pos.x;
afficher(idle,objet[indice_objet],imageDeFond,ecran,pos,rect_objet,camera);


j=5;

}



}

      


break;
}*/

void init(SDL_Surface* *screen,Mix_Music* *MenuMusic,Mix_Chunk* *btnMenu,bg *menu,btn* buttons)
{
	if(SDL_Init(SDL_INIT_EVERYTHING) != 0){
		printf("Unable to init SDL: %s\n", SDL_GetError());
		exit(EXIT_FAILURE);
	}

	*screen = SDL_SetVideoMode(950,700,32,SDL_HWSURFACE | SDL_DOUBLEBUF);
	if(*screen == NULL){
		printf("Unable to Set video Mode : %s\n", SDL_GetError());
		exit(EXIT_FAILURE);
	}


	menu->img = SDL_LoadBMP("background.bmp");
	if(menu->img == NULL){
		printf("Unable to LOAD background : %s\n", SDL_GetError());
		exit(EXIT_FAILURE);
	}
	menu->pos.x = 0;
	menu->pos.y = 0;

if(Mix_OpenAudio(44100,MIX_DEFAULT_FORMAT,MIX_DEFAULT_CHANNELS,1024)==-1)
{
   printf("%s",Mix_GetError());
}


	*MenuMusic = Mix_LoadMUS("resource/soundtrack.mp3");


	*btnMenu = Mix_LoadWAV("resource/click.wav");
	buttons[0].img = IMG_Load("play.png");
	buttons[0].imgover = IMG_Load("play1.png");
	buttons[0].imgclick = IMG_Load("play2.png");
	if((buttons[0].img == NULL)|| (buttons[0].imgover == NULL) || (buttons[0].imgclick == NULL)){
		printf("Unable to LOAD buttons 0 : %s\n", SDL_GetError());
		exit(EXIT_FAILURE);
	}
	buttons[0].pos.x = 40;
	buttons[0].pos.y = 170;

	buttons[0].soundover = 0;
	buttons[0].soundclick = 0;

	buttons[1].img = IMG_Load("options.png");
	buttons[1].imgover = IMG_Load("options1.png");
	buttons[1].imgclick = IMG_Load("options2.png");
	if((buttons[1].img == NULL) || (buttons[1].imgover == NULL) || (buttons[1].imgclick) == NULL){
		printf("Unable to LOAD buttons 0 : %s\n", SDL_GetError());
		exit(EXIT_FAILURE);
	}
	buttons[1].pos.x = 40;
	buttons[1].pos.y = 270;

	buttons[1].soundover = 0;
	buttons[1].soundclick = 0;


	buttons[2].img = IMG_Load("credits.png");
	buttons[2].imgover = IMG_Load("credits1.png");
	buttons[2].imgclick = IMG_Load("credit2.png");
	if((buttons[2].img == NULL)|| (buttons[2].imgover == NULL)){
		printf("Unable to LOAD buttons 0 : %s\n", SDL_GetError());
		exit(EXIT_FAILURE);
	}
	buttons[2].pos.x = 25;
	buttons[2].pos.y = 370;

	buttons[2].soundover = 0;
	buttons[2].soundclick = 0;

	buttons[3].img = IMG_Load("exit.png");
	buttons[3].imgover = IMG_Load("exit1.png");
	buttons[3].imgclick = IMG_Load("exit2.png");
	if((buttons[3].img == NULL)|| (buttons[3].imgover == NULL)){
		printf("Unable to LOAD buttons 0 : %s\n", SDL_GetError());
		exit(EXIT_FAILURE);
	}
	buttons[3].pos.x = 30;
	buttons[3].pos.y = 470;

	buttons[3].soundover = 0;
	buttons[3].soundclick = 0;

}

int over(int x,int y,SDL_Rect pos){
	return (x > pos.x && x < pos.x + pos.w && y > pos.y && y < pos.y + pos.h);
}

int menug(SDL_Surface* screen,Mix_Music* MenuMusic,Mix_Chunk* btnMenu,bg menu,btn* buttons){
	Uint8 p;
	int choix = -1,x,y;
	do{
		SDL_PumpEvents();
		p = SDL_GetMouseState(&x,&y);
		SDL_BlitSurface(menu.img,NULL,screen,&menu.pos);
		for(int i = 0 ;i < 4;i++){
			if(!over(x,y,buttons[i].pos)){
				SDL_BlitSurface(buttons[i].img,NULL,screen,&buttons[i].pos);
				buttons[i].soundover = 0;
	            buttons[i].soundclick = 0;

			}else{
				SDL_BlitSurface(buttons[i].imgover,NULL,screen,&buttons[i].pos);
				if(!buttons[i].soundover){
						Mix_PlayChannel(-1,btnMenu,0);
						buttons[i].soundover = 1;
				}
				if (SDL_GetMouseState(NULL, NULL) & SDL_BUTTON(SDL_BUTTON_LEFT)) {
					if (SDL_BUTTON_LEFT)
					{
						SDL_BlitSurface(buttons[i].imgclick,NULL,screen,&buttons[i].pos);
					}
					if(!buttons[i].soundclick){
						Mix_PlayChannel(-1,btnMenu,0);
						buttons[i].soundclick = 1;

					}
					choix = i+1;
				
				}

			}

		}
		SDL_Flip(screen);
	}while(choix == -1);
	return choix;
}
