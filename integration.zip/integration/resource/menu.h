#ifndef MENU_H_INCLUDE
#define MENU_H_INCLUDE

typedef struct {
	SDL_Surface *img;
	SDL_Rect pos;
}bg;



typedef struct {
	SDL_Surface *img,*imgover,*imgclick;
	SDL_Rect pos;
	int soundover,soundclick;

}btn;
void display(SDL_Surface *ecran,SDL_Surface *bg,SDL_Surface *img,SDL_Surface *img1,SDL_Surface *img2,SDL_Rect pos,SDL_Rect pos1,SDL_Rect pos2);
void init(SDL_Surface* *screen,Mix_Music* *MenuMusic,Mix_Chunk* *btnMenu,bg *menu, btn* buttons);
int menug(SDL_Surface* screen,Mix_Music* MenuMusic,Mix_Chunk* btnMenu,bg menu,btn* buttons);
void stage();
bool collision(SDL_Rect* rect1,SDL_Rect* rect2);
void init_objet(SDL_Surface*objet[]);
void health_bar(SDL_Surface *health[]);
void init_objet_1(SDL_Surface*objet []);
int collision_Parfaite(SDL_Surface *calque,SDL_Surface *perso,SDL_Rect posperso,int d);
void walk_anim(SDL_Surface *anim[]);
void walk_back(SDL_Surface *anim[]);
void jump_anim(SDL_Surface *slide_back[]);
void afficher(SDL_Surface * img1,SDL_Surface * img2,SDL_Surface * img3,SDL_Surface * img4,SDL_Surface * bg,SDL_Surface * ecran,SDL_Rect pos1,SDL_Rect pos2,SDL_Rect pos3,SDL_Rect pos4,SDL_Rect camera,SDL_Rect pospartage,SDL_Rect poss1,SDL_Rect poss2,SDL_Rect poss3,SDL_Rect poss4);

int Enigme2 ();
#endif
