#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include "/usr/include/SDL/SDL.h"
#include "/usr/include/SDL/SDL_image.h"
#include "/usr/include/SDL/SDL_mixer.h"
#include "/usr/include/SDL/SDL_ttf.h"
#include "resource/menu.h"
int main()
{
	SDL_Surface *screen;
	Mix_Music *MenuMusic;
	Mix_Chunk *btnMenu;
	btn buttons[10];
	bg menu;
	int done = 0, choix;
	init(&screen,&MenuMusic,&btnMenu,&menu, buttons);
	Mix_PlayMusic(MenuMusic,-1);
	while(!done)
	{
		choix = menug(screen,MenuMusic,btnMenu,menu, buttons);
		switch(choix){
			case 1:
			stage();
				break;
			case 2:
				break;
			case 3:
				break;
			case 4:
				done = 1;
				break;
		}

	}

	SDL_FreeSurface(screen);
	SDL_FreeSurface(menu.img);
	Mix_FreeMusic(MenuMusic);
	Mix_FreeChunk(btnMenu);
}
