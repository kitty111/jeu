#include <stdio.h>
#include <stdlib.h>
#include "option.h"
#include "/usr/include/SDL/SDL.h"
#include "/usr/include/SDL/SDL_image.h"
#include "/usr/include/SDL/SDL_mixer.h"

void Option(int *m, int *s)
{
	  SDL_Surface *ecran = NULL, *fond = NULL, *T[11];
    SDL_Rect positionFond ;
    SDL_Event event;   
    Mix_Chunk* btnMenu;
    Mix_Music *MenuMusic;
    positionFond.x = 0;
    positionFond.y = 0;
    int choix,i,continuer;

    SDL_Init(SDL_INIT_VIDEO);
    ecran = SDL_SetVideoMode(900, 1140, 32, SDL_HWSURFACE | SDL_DOUBLEBUF);
    SDL_WM_SetCaption("Options", NULL);


    T[0]  = IMG_Load("0.png");
    T[1]  = IMG_Load("1.png");
    T[2]  = IMG_Load("2.png");
    T[3]  = IMG_Load("3.png");
    T[4]  = IMG_Load("4.png");
    T[5]  = IMG_Load("5.png");
    T[6]  = IMG_Load("6.png");
    T[7]  = IMG_Load("7.png");
    T[8]  = IMG_Load("8.png");
    T[9]  = IMG_Load("9.png");
    T[10] = IMG_Load("10.png");
    T[11] = IMG_Load("11.png");

    fond= T[0];
    SDL_BlitSurface(fond,NULL,ecran,&positionFond);
    SDL_Flip(ecran); 

    for (i=0 ; i<11 ; i++)
    {

            while (continuer) //tant qu elle ne vaut pas 0
            {
              while(SDL_PollEvent(&event))//lors de l appui sur la touche 
 
                 {
                   if(event.type ==SDL_QUIT)   
                      {
                        continuer=0;
                        break;
                      }

                    switch(event.type)
                      {
                         case SDL_QUIT:
                         continuer=0;
                         break;
                      case SDL_KEYDOWN:
                      {
                      	switch(event.key.keysym.sym)
                            {
                               case SDLK_RIGHT:
                                   {
                                   	fond = T[i+1];
                                   	SDL_BlitSurface(fond,NULL,ecran,&positionFond);
                                   	SDL_Flip(ecran);
                                   	SDL_Delay(200);
                                   	break;
                                   }
                                
                                case SDLK_LEFT:
                                   {
                                   	fond = T[i-1];
                                   	SDL_BlitSurface(fond,NULL,ecran,&positionFond);
                                   	SDL_Flip(ecran);
                                   	SDL_Delay(200);
                                   	break;
                                   }

                                 case SDLK_0:
                                   {
                                   	if (fond = T[0])
                                   	{
                                   		fond = IMG_Load("NotYet.png");
                                   		SDL_BlitSurface(fond,NULL,ecran,&positionFond);
                                        SDL_Flip(ecran);
                                        SDL_Delay(200);
                                        break;
                                   	}
                                   	
                                   	if (fond = T[3])
                                   	{
                                   		if ((*s) == 1)
                                   			*s = 0;
                                   		else 
                                   			*s = 1;
                                   	}

                                   	if (fond = T[6])
                                   	{
                                   		fond = IMG_Load("NotYet.png");
                                   		SDL_BlitSurface(fond,NULL,ecran,&positionFond);
                                        SDL_Flip(ecran);
                                        SDL_Delay(200);
                                        break;
                                   	}

                                   	if (fond = T[9])
                                   	{
                                   		if ((*m) == 1)
                                   			(*m) = 0;
                                   		else 
                                   			(*m) = 1;
                                   	}

                                   	break;
                                   }
                             break;
                            }
                       }

                  }

            }
     }
   }
}


    





