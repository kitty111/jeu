#include <stdio.h>
#include <stdlib.h>
#include "option.h"
#include "/usr/include/SDL/SDL.h"
#include "/usr/include/SDL/SDL_image.h"
#include "/usr/include/SDL/SDL_mixer.h"

int main()
{
	Mix_Chunk* btnMenu;
    Mix_Music* MenuMusic;
    int m=1 , s=1;
    
	while (1)
	{
		 Option(&m, &s);

	if (s==1)
        btnMenu = Mix_LoadWAV("click.wav");
    else 
    	btnMenu = NULL;


    if (m==1)
        MenuMusic = Mix_LoadMUS("soundtrack.mp3");
    else
    	MenuMusic = NULL;
	}
	

   
}