#ifndef OPTION_H_INCLUDE
#define OPTION_H_INCLUDE

void Option(int *m, int *s);

#endif